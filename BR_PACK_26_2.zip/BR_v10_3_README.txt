Battle Royale v10.3 resource pack
- Same hollow tactical ADS optic: Assault Rifle, Sniper, Grenade Launcher
- Sniper has a substantially longer barrel
- Grenade launcher uses its own scoped model
- Existing gun orientation from v10.2 preserved
